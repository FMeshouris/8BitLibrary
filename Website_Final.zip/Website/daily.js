//Window Resise listener code taken from https://developer.mozilla.org/en-US/docs/Web/API/Window/resize_event
let wWidth = window.innerWidth;
let wHeight = window.innerHeight;
let wRatio = wWidth/wHeight;
let imgHeight = (wHeight/100)*34-(wWidth/100)*1.3-9;
document.getElementById("daily_img").style.height = imgHeight;
addEventListener("resize", (event) => { })
onresize = (event) => {
    //This code takes the width and height of the window and uses it to find the ratio between vw and vh.
    let wWidth = window.innerWidth;
    let wHeight = window.innerHeight;
    let wRatio = wWidth/wHeight;
    let imgHeight = (wHeight/100)*34-(wWidth/100)*1.3-9;
    document.getElementById("daily_img").style.height = imgHeight;
}
let date = new(Date);
document.getElementById("daily_img").src = "Images/game_"+(date.getDate() % 10 + 1).toString()+".jpg";
