function toPage(id){
    let page = document.getElementById(id);
    let header = document.getElementById("header2");
    var scrollTop = window.pageYOffset;
    window.scrollTo(0, page.getBoundingClientRect().top+scrollTop-header.getBoundingClientRect().height-15);
    if (id == "top") {
        window.scrollTo(0, 0);
    }
    console.log(scrollTop)
}