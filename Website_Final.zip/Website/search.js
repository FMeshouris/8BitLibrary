let pages = [
    "Super Mario 64 [Nintendo64 N64 Nintendo 64]",
    "Sonic the Hedgehog [Sega Genesis]",
    "Pokemon Red [Nintendo Gameboy game boy]",
    "Donkey Kong Country [SNES Super Nintendo Entertainment System]",
    "Super Metroid [SNES Super Nintendo Entertainment System]",
    "Mega Man 2 [NES Nintendo Entertainment System]",
    "Tetris [Nintendo Gameboy game boy]",
    "F-Zero [SNES Super Nintendo Entertainment System]",
    "Super Mario Bros. [NES Nintendo Entertainment System]",
    "Streets of Rage 2 [Sega Genesis]" 
]

let dropdown = document.getElementById("dropdown-content");
dropdown.style.display = "none";
function search() {
    let text = document.getElementById("searchbar input").value.toLowerCase();
    let elegable_pages = []
    for(i=0; i < pages.length; i++){
        if(pages[i].toLowerCase().indexOf(text) !== -1){
            elegable_pages.push(pages[i].split(" [")[0]);
        }
    }
    dropdown.innerHTML = ""
    for(i=0; i < elegable_pages.length; i++){
        let hyperlink = elegable_pages[i].toLowerCase().replaceAll(" ", "_").replaceAll(".", "")+".html"
        dropdown.innerHTML += '<a href="' + hyperlink + '"\>' + elegable_pages[i] + '</a>';
        console.log(elegable_pages[i])
    }
}

function show_searchlist() {
    dropdown.style.display = "flex";
}

function hide_searchlist() {
    setTimeout(() => {dropdown.style.display = "none";}
    , 100);
}



function show_gameslist() {
    document.getElementById("games-dropdown").style.display = "flex";
}
function hide_gameslist() {
    document.getElementById("games-dropdown").style.display = "none";
}

function show_consoleslist() {
    document.getElementById("consoles-dropdown").style.display = "flex";
}
function hide_consoleslist() {
    document.getElementById("consoles-dropdown").style.display = "none";
}