let r = document.querySelector(':root');
if(checkCookie("font") == "sans-serif"){
    r.style.setProperty('--font', 'sans-serif');
    r.style.setProperty('--fontsize', '1.3');
}
function checkCookie(cname){
        let name = cname + "=";
        let ca = document.cookie.split(';');
        for(let i = 0; i < ca.length; i++) {
        let c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function fontChange(){
    if(checkCookie("font") == "pixel"){
        r.style.setProperty('--font', 'sans-serif');
        r.style.setProperty('--fontsize', '1.3');
        document.cookie = "font=sans-serif; path=/";
    }
    else if(checkCookie("font") == "sans-serif"){
        r.style.setProperty('--font', 'Pixel');
        r.style.setProperty('--fontsize', '1');
        document.cookie = "font=pixel; path=/";
    }
    else{
        r.style.setProperty('--font', 'sans-serif');
        r.style.setProperty('--fontsize', '1.3');
        document.getElementById("cookies_popup").style.display = "flex";
    }
}

function cookies(allowed){
    if(allowed==true){
        document.cookie = "font=sans-serif; path=/";
    }
    document.getElementById("cookies_popup").style.display = "none";
}